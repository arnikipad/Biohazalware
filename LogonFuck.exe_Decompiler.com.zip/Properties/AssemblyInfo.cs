using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using A;

[assembly: AssemblyProduct("LogonFuck")]
[assembly: AssemblyCopyright("gabrik Copyright ©  2020")]
[assembly: AssemblyCompany("gabrik")]
[assembly: AssemblyDescription("A virus made by gabrik")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyInfo("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("06128e52-e9be-47ca-904e-5b8de063b751")]
[assembly: SuppressIldasm]
[assembly: AssemblyTitle("LogonFuck")]
[assembly: AssemblyVersion("1.0.0.0")]
